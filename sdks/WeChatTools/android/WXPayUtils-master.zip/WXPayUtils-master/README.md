# WXPayUtils
微信支付的总结
 
详细 介绍请参考：http://www.jianshu.com/p/433307f17b4f
