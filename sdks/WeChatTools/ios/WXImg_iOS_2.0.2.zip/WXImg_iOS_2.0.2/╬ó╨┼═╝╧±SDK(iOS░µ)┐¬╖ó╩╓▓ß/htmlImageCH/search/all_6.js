var searchData=
[
  ['setappid_3a',['setAppID:',['../interface_w_x_image_search.html#a3bc5391c696d45083b37740b3a9320f0',1,'WXImageSearch']]],
  ['sharedimagesearch',['sharedImageSearch',['../interface_w_x_image_search.html#aac53379f50a5d7d78649495274822a8b',1,'WXImageSearch']]],
  ['startwithimage_3a',['startWithImage:',['../interface_w_x_image_search.html#a64cce16aeb3995056b751d3eb65fe3ca',1,'WXImageSearch']]],
  ['startwithjpgimagedata_3a',['startWithJPGImageData:',['../interface_w_x_image_search.html#a46b66d5da3ed7d625166677b6153e5b0',1,'WXImageSearch']]]
];
