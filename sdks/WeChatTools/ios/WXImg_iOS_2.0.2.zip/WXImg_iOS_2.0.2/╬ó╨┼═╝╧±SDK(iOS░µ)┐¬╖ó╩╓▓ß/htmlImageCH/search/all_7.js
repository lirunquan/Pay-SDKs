var searchData=
[
  ['url',['url',['../interface_w_x_image_search_result.html#a977ec05fb7fbe3e323023c5d583141f9',1,'WXImageSearchResult']]]
];
