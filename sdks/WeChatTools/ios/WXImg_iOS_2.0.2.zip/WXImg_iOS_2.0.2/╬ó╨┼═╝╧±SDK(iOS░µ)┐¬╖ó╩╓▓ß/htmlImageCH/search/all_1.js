var searchData=
[
  ['delegate',['delegate',['../interface_w_x_image_search.html#a8b568a9c1ce69fabe6886a7c4c318f1b',1,'WXImageSearch']]]
];
