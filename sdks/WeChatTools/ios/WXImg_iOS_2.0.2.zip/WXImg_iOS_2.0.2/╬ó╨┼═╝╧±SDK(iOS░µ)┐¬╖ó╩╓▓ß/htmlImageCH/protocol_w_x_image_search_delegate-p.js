var protocol_w_x_image_search_delegate_p =
[
    [ "imageSearchDidCancel", "protocol_w_x_image_search_delegate-p.html#a94add7c385b89ca307a4bca42d9a416f", null ],
    [ "imageSearchMakeError:", "protocol_w_x_image_search_delegate-p.html#a79ea09d00c275455a1a5e7d97f08e984", null ],
    [ "imageSearchResultArray:", "protocol_w_x_image_search_delegate-p.html#ad68c12569c8dd8613b9f6dacd100ca0d", null ]
];